﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise7
{
    public class MeasurementConversion
    {

        public enum ValueType
        {
            MilliMeters,
            Centimeters,
            Meters,
            KiloMeters
        }

        public int ToMeters(ValueType valueType, int value)
        {
            throw new NotImplementedException();
        }

        public int ToMilliMeters(ValueType valueType, int value)
        {
            throw new NotImplementedException();
        }

        public int ToCentiMeters(ValueType valueType, int value)
        {
            throw new NotImplementedException();
        }

        public int ToKiloMeters(ValueType valueType, int value)
        {
            throw new NotImplementedException();
        }

    }
}
